package com.raylan.iaprofissional.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.raylan.iaprofissional.engine.GeminiScriptClient
import com.raylan.iaprofissional.engine.VideoRenderEngine
import com.raylan.iaprofissional.model.RenderState
import com.raylan.iaprofissional.model.StudioMode
import com.raylan.iaprofissional.model.TargetDuration
import com.raylan.iaprofissional.model.TargetResolution
import com.raylan.iaprofissional.model.TransitionStyle
import com.raylan.iaprofissional.ui.theme.StudioColors
import kotlinx.coroutines.launch

@Composable
fun StudioScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var activeMode by remember { mutableStateOf(StudioMode.PROMPT_AND_CLIPS) }
    var promptText by remember {
        mutableStateOf("Edit Gojo 4K com batida forte e flash")
    }
    var remixPromptText by remember {
        mutableStateOf("Deixar estilo edit profissional de anime com nitidez 4K, contraste alto, camera shake e transição suave")
    }
    var selectedClips by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var singleRemixVideo by remember { mutableStateOf<Uri?>(null) }

    var selectedDuration by remember { mutableStateOf(TargetDuration.SEC_30) }
    var selectedResolution by remember { mutableStateOf(TargetResolution.UHD_4K) }
    var selectedTransition by remember { mutableStateOf(TransitionStyle.WHITE_FLASH) }

    var showApiKeyPanel by remember { mutableStateOf(false) }
    var apiKeyInput by remember { mutableStateOf(GeminiScriptClient.loadCustomApiKey(context)) }
    var renderState by remember { mutableStateOf<RenderState>(RenderState.Idle) }

    val multiVideoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
    ) { uris ->
        runCatching {
            if (uris.isNotEmpty()) {
                selectedClips = uris
            }
        }
    }

    val singleVideoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        runCatching {
            if (uri != null) {
                singleRemixVideo = uri
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioColors.PureBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        // Cabeçalho Minimalista P&B
        StudioHeader(
            onToggleApiKey = { showApiKeyPanel = !showApiKeyPanel },
            hasCustomKey = apiKeyInput.isNotBlank()
        )

        if (showApiKeyPanel) {
            Spacer(modifier = Modifier.height(14.dp))
            ApiKeyCard(
                apiKey = apiKeyInput,
                onApiKeyChange = { apiKeyInput = it },
                onSave = {
                    GeminiScriptClient.saveCustomApiKey(context, apiKeyInput)
                    showApiKeyPanel = false
                    Toast.makeText(
                        context,
                        if (apiKeyInput.isBlank()) "Usando chave padrão protegida do estúdio." else "Chave personalizada salva.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Seletor de Modo (A: Prompt + Clipes | B: Remix de Vídeo Único)
        ModeSelectorRow(
            activeMode = activeMode,
            onSelectMode = { activeMode = it }
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Prompt do Usuário
        val currentPrompt = if (activeMode == StudioMode.PROMPT_AND_CLIPS) promptText else remixPromptText
        Text(
            text = if (activeMode == StudioMode.PROMPT_AND_CLIPS) "COMANDO DA EDIT" else "INSTRUÇÕES DE REMIX",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = StudioColors.MutedGray
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = currentPrompt,
            onValueChange = { value ->
                if (activeMode == StudioMode.PROMPT_AND_CLIPS) {
                    promptText = value
                } else {
                    remixPromptText = value
                }
            },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            maxLines = 5,
            placeholder = {
                Text(
                    text = if (activeMode == StudioMode.PROMPT_AND_CLIPS) {
                        "Ex: Faz uma edit do Naruto com transição simples"
                    } else {
                        "Ex: Deixar estilo edit profissional de anime com nitidez 4K..."
                    },
                    color = StudioColors.MutedGray,
                    fontSize = 13.sp
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = StudioColors.Graphite,
                unfocusedContainerColor = StudioColors.Graphite,
                focusedBorderColor = StudioColors.PureWhite,
                unfocusedBorderColor = StudioColors.BorderGray,
                focusedTextColor = StudioColors.PureWhite,
                unfocusedTextColor = StudioColors.PureWhite,
                cursorColor = StudioColors.PureWhite
            ),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Seletor de Vídeos da Galeria
        if (activeMode == StudioMode.PROMPT_AND_CLIPS) {
            VideoPickerSection(
                title = "CLIPES SELECIONADOS (${selectedClips.size})",
                buttonLabel = if (selectedClips.isEmpty()) "SELECIONAR CLIPES DA GALERIA" else "ALTERAR CLIPES (${selectedClips.size})",
                onClick = {
                    runCatching {
                        multiVideoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    }.onFailure {
                        Toast.makeText(context, "Erro ao abrir galeria.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        } else {
            VideoPickerSection(
                title = if (singleRemixVideo != null) "1 VÍDEO PRONTO PARA REMIX" else "NENHUM VÍDEO SELECIONADO",
                buttonLabel = if (singleRemixVideo == null) "ESCOLHER VÍDEO ÚNICO" else "TROCAR VÍDEO ÚNICO",
                onClick = {
                    runCatching {
                        singleVideoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    }.onFailure {
                        Toast.makeText(context, "Erro ao abrir galeria.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Duração Alvo (15s, 30s, 45s, 60s)
        Text(
            text = "DURAÇÃO ALVO",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = StudioColors.MutedGray
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TargetDuration.entries.forEach { duration ->
                SelectableOptionChip(
                    label = duration.label,
                    selected = selectedDuration == duration,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedDuration = duration }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Resolução (1080p Full HD | 4K Ultra HD 2160p)
        Text(
            text = "RESOLUÇÃO DE EXPORTAÇÃO",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = StudioColors.MutedGray
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TargetResolution.entries.forEach { res ->
                SelectableOptionChip(
                    label = res.label,
                    selected = selectedResolution == res,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedResolution = res }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Estilo de Transição
        Text(
            text = "ESTILO DE TRANSIÇÃO",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = StudioColors.MutedGray
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransitionStyle.entries.forEach { style ->
                SelectableOptionChip(
                    label = style.label,
                    selected = selectedTransition == style,
                    onClick = { selectedTransition = style }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Botão Principal de Renderização
        val isBusy = renderState is RenderState.Analyzing || renderState is RenderState.Rendering
        Button(
            onClick = {
                val inputVideos = if (activeMode == StudioMode.PROMPT_AND_CLIPS) {
                    selectedClips
                } else {
                    listOfNotNull(singleRemixVideo)
                }

                if (inputVideos.isEmpty()) {
                    Toast.makeText(context, "Selecione ao menos 1 vídeo da galeria.", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                scope.launch {
                    renderState = RenderState.Analyzing("Interpretando roteiro de edição...")
                    val script = GeminiScriptClient.generateEditScript(
                        context = context,
                        prompt = currentPrompt,
                        clipCount = inputVideos.size,
                        mode = activeMode,
                        duration = selectedDuration,
                        resolution = selectedResolution,
                        transitionStyle = selectedTransition
                    )

                    val result = VideoRenderEngine.renderAndSaveToGallery(
                        context = context,
                        inputUris = inputVideos,
                        script = script
                    ) { progress, stage ->
                        renderState = RenderState.Rendering(progress, stage)
                    }

                    renderState = result.fold(
                        onSuccess = { (uri, fileName) ->
                            RenderState.Completed(uri, fileName, script)
                        },
                        onFailure = { err ->
                            RenderState.Error(err.localizedMessage ?: "Falha na renderização Media3.")
                        }
                    )
                }
            },
            enabled = !isBusy,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = StudioColors.PureWhite,
                contentColor = StudioColors.PureBlack,
                disabledContainerColor = StudioColors.BorderGray,
                disabledContentColor = StudioColors.MutedGray
            )
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (activeMode == StudioMode.PROMPT_AND_CLIPS) {
                    "RENDERIZAR EDIT ${selectedResolution.shortLabel.uppercase()}"
                } else {
                    "REMIXAR VÍDEO ${selectedResolution.shortLabel.uppercase()}"
                },
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 13.sp,
                letterSpacing = 0.6.sp
            )
        }

        // Progresso em Tempo Real, Erro ou Player ExoPlayer Integrado
        when (val state = renderState) {
            is RenderState.Analyzing -> {
                Spacer(modifier = Modifier.height(16.dp))
                RenderProgressBox(progressPercent = 12, label = state.message)
            }

            is RenderState.Rendering -> {
                Spacer(modifier = Modifier.height(16.dp))
                RenderProgressBox(progressPercent = state.progressPercent, label = state.stageLabel)
            }

            is RenderState.Error -> {
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StudioColors.Graphite, RoundedCornerShape(10.dp))
                        .border(1.dp, StudioColors.BorderGray, RoundedCornerShape(10.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = "Erro: ${state.message}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = StudioColors.PureWhite
                    )
                }
            }

            is RenderState.Completed -> {
                Spacer(modifier = Modifier.height(20.dp))
                CompletedPlayerSection(
                    outputUri = state.outputUri,
                    fileName = state.fileName,
                    summary = state.script.summaryNote,
                    engineSource = state.script.engineSource,
                    onSaveGallery = {
                        Toast.makeText(
                            context,
                            "Salvo em Movies/IAProfissional/${state.fileName}",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    onShare = {
                        runCatching {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"
                                putExtra(Intent.EXTRA_STREAM, state.outputUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Compartilhar Edit"))
                        }.onFailure {
                            Toast.makeText(context, "Não foi possível compartilhar.", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }

            RenderState.Idle -> Unit
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
private fun StudioHeader(
    onToggleApiKey: () -> Unit,
    hasCustomKey: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "AI PROFISSIONAL",
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    letterSpacing = (-0.5).sp,
                    color = StudioColors.PureWhite
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .background(StudioColors.PureWhite, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "4K STUDIO ENGINE",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 10.sp,
                        color = StudioColors.PureBlack
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Desenvolvido por Raylan",
                    fontFamily = FontFamily.Default,
                    fontSize = 12.sp,
                    color = StudioColors.MutedGray
                )
            }
        }

        Box(
            modifier = Modifier
                .background(StudioColors.Graphite, RoundedCornerShape(8.dp))
                .border(
                    width = 1.dp,
                    color = StudioColors.PureWhite,
                    shape = RoundedCornerShape(8.dp)
                )
                .clickable { onToggleApiKey() }
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = "Configuração Avançada Gemini",
                    tint = StudioColors.PureWhite,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (hasCustomKey) "API CUSTOM" else "GEMINI AUTO",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = StudioColors.PureWhite
                )
            }
        }
    }
}

@Composable
private fun ApiKeyCard(
    apiKey: String,
    onApiKeyChange: (String) -> Unit,
    onSave: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.Graphite, RoundedCornerShape(10.dp))
            .border(1.dp, StudioColors.BorderGray, RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) {
        Text(
            text = "CONEXÃO GEMINI 3.8 FLASH (AVANÇADO)",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = StudioColors.PureWhite
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Conectado automaticamente via ApiKeyVault protegido. Deixe em branco para usar a chave padrão ou insira outra abaixo.",
            fontSize = 12.sp,
            color = StudioColors.MutedGray
        )
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = apiKey,
            onValueChange = onApiKeyChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            placeholder = { Text("Opcional: substituir chave padrão", color = StudioColors.MutedGray) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = StudioColors.PureBlack,
                unfocusedContainerColor = StudioColors.PureBlack,
                focusedBorderColor = StudioColors.PureWhite,
                unfocusedBorderColor = StudioColors.BorderGray,
                focusedTextColor = StudioColors.PureWhite,
                unfocusedTextColor = StudioColors.PureWhite
            )
        )
        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = onSave,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = StudioColors.PureWhite,
                contentColor = StudioColors.PureBlack
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "SALVAR CONFIGURAÇÃO",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun ModeSelectorRow(
    activeMode: StudioMode,
    onSelectMode: (StudioMode) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.Graphite, RoundedCornerShape(10.dp))
            .border(1.dp, StudioColors.BorderGray, RoundedCornerShape(10.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        StudioMode.entries.forEach { mode ->
            val selected = mode == activeMode
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(7.dp))
                    .background(if (selected) StudioColors.PureWhite else StudioColors.Graphite)
                    .clickable { onSelectMode(mode) }
                    .padding(vertical = 12.dp, horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = mode.label,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (selected) StudioColors.PureBlack else StudioColors.MutedGray
                )
            }
        }
    }
}

@Composable
private fun VideoPickerSection(
    title: String,
    buttonLabel: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.Graphite, RoundedCornerShape(10.dp))
            .border(1.dp, StudioColors.BorderGray, RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.VideoLibrary,
                    contentDescription = null,
                    tint = StudioColors.PureWhite,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = StudioColors.PureWhite
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, StudioColors.PureWhite),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = StudioColors.PureWhite
            )
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = buttonLabel,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun SelectableOptionChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) StudioColors.PureWhite else StudioColors.Graphite)
            .border(
                width = 1.dp,
                color = if (selected) StudioColors.PureWhite else StudioColors.BorderGray,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontFamily = FontFamily.Default,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (selected) StudioColors.PureBlack else StudioColors.PureWhite
        )
    }
}

@Composable
private fun RenderProgressBox(
    progressPercent: Int,
    label: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.Graphite, RoundedCornerShape(10.dp))
            .border(1.dp, StudioColors.BorderGray, RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                fontFamily = FontFamily.Default,
                fontSize = 12.sp,
                color = StudioColors.PureWhite
            )
            Text(
                text = "$progressPercent%",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = StudioColors.PureWhite
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { progressPercent / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = StudioColors.PureWhite,
            trackColor = StudioColors.BorderGray
        )
    }
}

@Composable
private fun CompletedPlayerSection(
    outputUri: Uri,
    fileName: String,
    summary: String,
    engineSource: String,
    onSaveGallery: () -> Unit,
    onShare: () -> Unit
) {
    val context = LocalContext.current
    val exoPlayer = remember(outputUri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(outputUri))
            repeatMode = ExoPlayer.REPEAT_MODE_ALL
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            runCatching { exoPlayer.release() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.Graphite, RoundedCornerShape(12.dp))
            .border(1.dp, StudioColors.PureWhite, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text(
            text = "EDIT PRONTA · $engineSource",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = StudioColors.PureWhite
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = summary,
            fontSize = 12.sp,
            color = StudioColors.MutedGray
        )
        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
                .background(StudioColors.PureBlack)
                .border(1.dp, StudioColors.BorderGray, RoundedCornerShape(8.dp))
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = true
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Movies/IAProfissional/$fileName",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = StudioColors.MutedGray
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onSaveGallery,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudioColors.PureWhite,
                    contentColor = StudioColors.PureBlack
                )
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SALVAR NA GALERIA",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }

            OutlinedButton(
                onClick = onShare,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StudioColors.PureWhite),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = StudioColors.PureWhite
                )
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "COMPARTILHAR",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }
    }
}
