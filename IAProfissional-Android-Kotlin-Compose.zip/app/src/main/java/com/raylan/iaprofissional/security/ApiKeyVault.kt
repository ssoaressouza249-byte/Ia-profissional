package com.raylan.iaprofissional.security

import android.util.Base64
import java.nio.charset.StandardCharsets

/**
 * Cofre de chave API com ofuscação por fragmentação Base64 fora de ordem.
 * A chave padrão nunca aparece em texto puro no código ou no DEX compilado;
 * ela é remontada na memória RAM exclusivamente no momento da chamada HTTPS.
 */
object ApiKeyVault {

    // Fragmentos armazenados fora de ordem e codificados em Base64
    private val encodedSegments = arrayOf(
        "b3EzdnVpMzJlcA==", // índice real 2
        "WnV0eU9wenRsZV93", // índice real 4
        "QVEuQWI4Uk42Sg==", // índice real 0
        "ZmtPM0IteGhsYXI=", // índice real 3
        "X2dMWXZ5MEVNeA=="  // índice real 1
    )

    private val reconstructionOrder = intArrayOf(2, 4, 0, 3, 1)

    fun reconstructKeyInMemory(): String {
        return runCatching {
            val buffer = StringBuilder(64)
            for (slot in reconstructionOrder) {
                val decodedBytes = Base64.decode(encodedSegments[slot], Base64.DEFAULT)
                buffer.append(String(decodedBytes, StandardCharsets.UTF_8))
                decodedBytes.fill(0)
            }
            val result = buffer.toString()
            buffer.setLength(0)
            result
        }.getOrDefault("")
    }
}
