package com.raylan.iaprofissional

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.ui.Modifier
import com.raylan.iaprofissional.security.SecurityGuard
import com.raylan.iaprofissional.security.SecurityLockScreen
import com.raylan.iaprofissional.ui.StudioScreen
import com.raylan.iaprofissional.ui.theme.IAProfissionalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val integrityReport = SecurityGuard.verifyIntegrity(this)

        setContent {
            IAProfissionalTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding()
                ) {
                    if (!integrityReport.isIntact) {
                        SecurityLockScreen(report = integrityReport)
                    } else {
                        StudioScreen()
                    }
                }
            }
        }
    }
}
