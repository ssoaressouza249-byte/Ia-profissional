package com.raylan.iaprofissional.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.iaprofissional.R

data class IntegrityReport(
    val isIntact: Boolean,
    val detectedAppName: String,
    val detectedPackageName: String
)

object SecurityGuard {
    const val EXPECTED_APP_NAME = "IA Profissional"
    const val EXPECTED_PACKAGE_NAME = "com.raylan.iaprofissional"

    /**
     * Verifica exclusivamente se o nome do aplicativo e o packageName originais
     * permanecem intactos, sem validar assinatura ou certificado para compatibilidade
     * total com builds de debug no GitHub Actions.
     */
    fun verifyIntegrity(context: Context): IntegrityReport {
        val currentPackage = runCatching { context.packageName }.getOrDefault("")
        val labelFromAppInfo = runCatching {
            context.applicationInfo.loadLabel(context.packageManager).toString()
        }.getOrDefault("")
        val labelFromRes = runCatching {
            context.getString(R.string.app_name)
        }.getOrDefault("")

        val isPackageValid = currentPackage == EXPECTED_PACKAGE_NAME
        val isNameValid = labelFromAppInfo == EXPECTED_APP_NAME && labelFromRes == EXPECTED_APP_NAME

        return IntegrityReport(
            isIntact = isPackageValid && isNameValid,
            detectedAppName = labelFromAppInfo.ifBlank { labelFromRes },
            detectedPackageName = currentPackage
        )
    }

    fun triggerSelfUninstall(context: Context) {
        runCatching {
            val uninstallIntent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(uninstallIntent)
        }
    }
}

@Composable
fun SecurityLockScreen(report: IntegrityReport) {
    val context = LocalContext.current

    // Bloqueia o botão voltar do Android para impedir qualquer saída da tela vermelha
    BackHandler(enabled = true) {}

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFB71C1C))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF7F0000), RoundedCornerShape(12.dp))
                .border(1.dp, Color.White, RoundedCornerShape(12.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Alerta de Modificação",
                tint = Color.White,
                modifier = Modifier.size(56.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "APLICATIVO MODIFICADO DETECTADO",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "O aplicativo original \"IA Profissional\" desenvolvido por Raylan foi alterado ou clonado sem autorização. O acesso foi bloqueado permanentemente.",
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Nome detectado: ${report.detectedAppName}\nPacote detectado: ${report.detectedPackageName}",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color(0xFFFFCDD2),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { SecurityGuard.triggerSelfUninstall(context) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF7F0000)
                )
            ) {
                Text(
                    text = "DESINSTALAR AGORA",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}
