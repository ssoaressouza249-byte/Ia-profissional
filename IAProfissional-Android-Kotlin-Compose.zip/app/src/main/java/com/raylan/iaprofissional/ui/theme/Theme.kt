package com.raylan.iaprofissional.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object StudioColors {
    val PureBlack = Color(0xFF000000)
    val Graphite = Color(0xFF121212)
    val BorderGray = Color(0xFF2A2A2A)
    val MutedGray = Color(0xFF8A8A8A)
    val PureWhite = Color(0xFFFFFFFF)
    val TamperRed = Color(0xFFB71C1C)
    val TamperRedDark = Color(0xFF7F0000)
}

private val StudioColorScheme = darkColorScheme(
    primary = StudioColors.PureWhite,
    onPrimary = StudioColors.PureBlack,
    secondary = StudioColors.PureWhite,
    onSecondary = StudioColors.PureBlack,
    background = StudioColors.PureBlack,
    onBackground = StudioColors.PureWhite,
    surface = StudioColors.Graphite,
    onSurface = StudioColors.PureWhite,
    surfaceVariant = StudioColors.Graphite,
    onSurfaceVariant = StudioColors.MutedGray,
    outline = StudioColors.BorderGray,
    outlineVariant = StudioColors.BorderGray
)

val StudioTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Black,
        fontSize = 28.sp,
        lineHeight = 32.sp,
        letterSpacing = (-0.5).sp,
        color = StudioColors.PureWhite
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 24.sp,
        color = StudioColors.PureWhite
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = StudioColors.PureWhite
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = StudioColors.PureWhite
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = StudioColors.MutedGray
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.8.sp,
        color = StudioColors.PureWhite
    )
)

@Composable
fun IAProfissionalTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = StudioColorScheme,
        typography = StudioTypography,
        content = content
    )
}
