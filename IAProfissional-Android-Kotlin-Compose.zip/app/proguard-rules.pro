# Preserve SecurityGuard and EditScript models
-keep class com.raylan.iaprofissional.security.** { *; }
-keep class com.raylan.iaprofissional.model.** { *; }
