package com.raylan.iaprofissional.model

import android.net.Uri

enum class StudioMode(val label: String) {
    PROMPT_AND_CLIPS("PROMPT + CLIPES"),
    SINGLE_VIDEO_REMIX("REMIX DE VÍDEO ÚNICO")
}

enum class TargetDuration(val seconds: Int, val label: String) {
    SEC_15(15, "15s"),
    SEC_30(30, "30s"),
    SEC_45(45, "45s"),
    SEC_60(60, "60s")
}

enum class TargetResolution(
    val heightPx: Int,
    val bitrateBps: Int,
    val label: String,
    val shortLabel: String
) {
    FHD_1080P(1080, 18_000_000, "1080p Full HD", "1080p"),
    UHD_4K(2160, 45_000_000, "4K Ultra HD 2160p", "4K 2160p")
}

enum class TransitionStyle(val label: String) {
    SIMPLE("Transição Simples"),
    HARD_CUT_BEAT_SYNC("Corte Seco / Beat Sync"),
    ZOOM_IMPACT("Zoom Impacto"),
    WHITE_FLASH("Flash Branco"),
    SLOW_MOTION("Slow Motion")
}

data class ClipCutSegment(
    val clipIndex: Int,
    val startMs: Long,
    val endMs: Long,
    val speedFactor: Float,
    val zoomScale: Float,
    val applyFlash: Boolean
)

data class EditScript(
    val engineSource: String,
    val themeTag: String,
    val targetDurationSec: Int,
    val resolution: TargetResolution,
    val transitionStyle: TransitionStyle,
    val cutIntervalMs: Long,
    val baseSpeedFactor: Float,
    val speedRampEnabled: Boolean,
    val zoomIntensity: Float,
    val flashEnabled: Boolean,
    val contrastBoost: Float,
    val saturationBoost: Float,
    val sharpness4k: Float,
    val cameraShakeIntensity: Float,
    val segments: List<ClipCutSegment> = emptyList(),
    val summaryNote: String
)

sealed class RenderState {
    data object Idle : RenderState()
    data class Analyzing(val message: String) : RenderState()
    data class Rendering(val progressPercent: Int, val stageLabel: String) : RenderState()
    data class Completed(
        val outputUri: Uri,
        val fileName: String,
        val script: EditScript
    ) : RenderState()
    data class Error(val message: String) : RenderState()
}
