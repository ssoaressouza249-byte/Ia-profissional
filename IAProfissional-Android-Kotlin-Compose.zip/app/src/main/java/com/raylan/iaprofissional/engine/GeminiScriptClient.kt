package com.raylan.iaprofissional.engine

import android.content.Context
import com.raylan.iaprofissional.model.ClipCutSegment
import com.raylan.iaprofissional.model.EditScript
import com.raylan.iaprofissional.model.StudioMode
import com.raylan.iaprofissional.model.TargetDuration
import com.raylan.iaprofissional.model.TargetResolution
import com.raylan.iaprofissional.model.TransitionStyle
import com.raylan.iaprofissional.security.ApiKeyVault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiScriptClient {

    private const val PREFS_NAME = "ia_profissional_prefs"
    private const val KEY_CUSTOM_GEMINI_API = "custom_gemini_api_key"
    private const val GEMINI_ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    fun loadCustomApiKey(context: Context): String {
        return runCatching {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_CUSTOM_GEMINI_API, "")
                .orEmpty()
        }.getOrDefault("")
    }

    fun saveCustomApiKey(context: Context, apiKey: String) {
        runCatching {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_CUSTOM_GEMINI_API, apiKey.trim())
                .apply()
        }
    }

    /**
     * Se o usuário definiu uma chave personalizada nas configurações avançadas, usa ela;
     * caso contrário, reconstrói a chave padrão protegida na RAM apenas durante a requisição.
     */
    private fun resolveEffectiveApiKey(context: Context): String {
        val custom = loadCustomApiKey(context).trim()
        return custom.ifBlank { ApiKeyVault.reconstructKeyInMemory() }
    }

    suspend fun generateEditScript(
        context: Context,
        prompt: String,
        clipCount: Int,
        mode: StudioMode,
        duration: TargetDuration,
        resolution: TargetResolution,
        transitionStyle: TransitionStyle
    ): EditScript = withContext(Dispatchers.IO) {
        val apiKey = resolveEffectiveApiKey(context).trim()
        if (apiKey.isBlank()) {
            return@withContext LocalSmartEngine.generateScript(
                prompt = prompt,
                clipCount = clipCount,
                mode = mode,
                duration = duration,
                resolution = resolution,
                selectedTransition = transitionStyle
            )
        }

        val remoteResult = runCatching {
            requestGeminiJson(
                apiKey = apiKey,
                prompt = prompt,
                clipCount = clipCount,
                mode = mode,
                duration = duration,
                resolution = resolution,
                transitionStyle = transitionStyle
            )
        }

        remoteResult.getOrElse {
            LocalSmartEngine.generateScript(
                prompt = prompt,
                clipCount = clipCount,
                mode = mode,
                duration = duration,
                resolution = resolution,
                selectedTransition = transitionStyle
            )
        }
    }

    private fun requestGeminiJson(
        apiKey: String,
        prompt: String,
        clipCount: Int,
        mode: StudioMode,
        duration: TargetDuration,
        resolution: TargetResolution,
        transitionStyle: TransitionStyle
    ): EditScript {
        val systemInstruction = """
            Você é o diretor de edição do app IA Profissional (4K Studio Engine).
            Analise o pedido do usuário para qualquer estilo e retorne EXCLUSIVAMENTE um JSON válido (sem markdown):
            Regras de estilo:
            - Free Fire / Games ("ff", "free fire", "capa", "highlight"): cortes rápidos no impacto (650-800ms), zoom punch (1.25-1.32), flash branco (true), saturação vibrante (+20 a +30) e camera shake forte.
            - Anime / AMV ("naruto", "gojo", "anime", "amv"): nitidez 4K (1.0), contraste cinematográfico (0.30-0.40), slow motion / speed ramp dinâmico e cortes sincronizados na batida.
            - Geral / Vlogs / Transição Simples ("simples", "suave", "vlog" ou outros): cortes limpos (1800-2500ms), transições suaves, zoom discreto (1.04-1.08) e ajuste equilibrado de cor/qualidade.

            Formato JSON obrigatório:
            {
              "themeTag": "string curta em MAIUSCULO",
              "cutIntervalMs": integer (600 a 3000),
              "baseSpeedFactor": float (0.5 a 1.5),
              "speedRampEnabled": boolean,
              "zoomIntensity": float (1.0 a 1.35),
              "flashEnabled": boolean,
              "contrastBoost": float (0.0 a 0.5),
              "saturationBoost": float (-20.0 a 35.0),
              "sharpness4k": float (0.4 a 1.0),
              "cameraShakeIntensity": float (0.0 a 1.0),
              "summaryNote": "resumo em português do roteiro de edição"
            }
            Contexto: modo=${mode.name}, clipes=$clipCount, duracao=${duration.seconds}s, resolucao=${resolution.shortLabel}, transicao=${transitionStyle.label}.
            Prompt do usuário: "$prompt"
        """.trimIndent()

        val payload = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", systemInstruction))
                    )
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.3)
                    put("responseMimeType", "application/json")
                }
            )
        }

        val request = Request.Builder()
            .url("$GEMINI_ENDPOINT?key=$apiKey")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        val bodyText = httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("HTTP ${response.code}")
            }
            response.body?.string() ?: error("Resposta vazia")
        }

        val root = JSONObject(bodyText)
        val rawJsonText = root
            .getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
            .trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val parsed = JSONObject(rawJsonText)
        val fallback = LocalSmartEngine.generateScript(
            prompt = prompt,
            clipCount = clipCount,
            mode = mode,
            duration = duration,
            resolution = resolution,
            selectedTransition = transitionStyle
        )

        val cutMs = parsed.optLong("cutIntervalMs", fallback.cutIntervalMs).coerceIn(500L, 3500L)
        val baseSpeed = parsed.optDouble("baseSpeedFactor", fallback.baseSpeedFactor.toDouble())
            .toFloat().coerceIn(0.45f, 1.6f)
        val speedRamp = parsed.optBoolean("speedRampEnabled", fallback.speedRampEnabled)
        val zoom = parsed.optDouble("zoomIntensity", fallback.zoomIntensity.toDouble())
            .toFloat().coerceIn(1.0f, 1.35f)
        val flash = parsed.optBoolean("flashEnabled", fallback.flashEnabled)
        val contrast = parsed.optDouble("contrastBoost", fallback.contrastBoost.toDouble())
            .toFloat().coerceIn(0f, 0.55f)
        val saturation = parsed.optDouble("saturationBoost", fallback.saturationBoost.toDouble())
            .toFloat().coerceIn(-30f, 40f)
        val sharpness = parsed.optDouble("sharpness4k", fallback.sharpness4k.toDouble())
            .toFloat().coerceIn(0.2f, 1.0f)
        val shake = parsed.optDouble("cameraShakeIntensity", fallback.cameraShakeIntensity.toDouble())
            .toFloat().coerceIn(0f, 1.0f)

        val safeClips = clipCount.coerceAtLeast(1)
        val totalMs = duration.seconds * 1000L
        val segments = buildList {
            var cursor = 0L
            var idx = 0
            while (cursor < totalMs) {
                val segLen = minOf(cutMs, totalMs - cursor)
                val segSpeed = if (speedRamp && idx % 3 == 1) (baseSpeed * 0.78f).coerceIn(0.45f, 1.5f) else baseSpeed
                val segZoom = if (idx % 2 == 0) zoom else 1.02f
                val offset = (idx / safeClips) * 1800L
                add(
                    ClipCutSegment(
                        clipIndex = idx % safeClips,
                        startMs = offset,
                        endMs = offset + segLen,
                        speedFactor = segSpeed,
                        zoomScale = segZoom,
                        applyFlash = flash && idx > 0
                    )
                )
                cursor += segLen
                idx++
            }
        }

        return EditScript(
            engineSource = "Gemini 3.8 Flash (API)",
            themeTag = parsed.optString("themeTag", fallback.themeTag),
            targetDurationSec = duration.seconds,
            resolution = resolution,
            transitionStyle = transitionStyle,
            cutIntervalMs = cutMs,
            baseSpeedFactor = baseSpeed,
            speedRampEnabled = speedRamp,
            zoomIntensity = zoom,
            flashEnabled = flash,
            contrastBoost = contrast,
            saturationBoost = saturation,
            sharpness4k = sharpness,
            cameraShakeIntensity = shake,
            segments = segments,
            summaryNote = parsed.optString("summaryNote", fallback.summaryNote)
        )
    }
}
