package com.raylan.iaprofissional.engine

import com.raylan.iaprofissional.model.ClipCutSegment
import com.raylan.iaprofissional.model.EditScript
import com.raylan.iaprofissional.model.StudioMode
import com.raylan.iaprofissional.model.TargetDuration
import com.raylan.iaprofissional.model.TargetResolution
import com.raylan.iaprofissional.model.TransitionStyle
import java.util.Locale

object LocalSmartEngine {

    fun generateScript(
        prompt: String,
        clipCount: Int,
        mode: StudioMode,
        duration: TargetDuration,
        resolution: TargetResolution,
        selectedTransition: TransitionStyle
    ): EditScript {
        val normalized = prompt.lowercase(Locale.ROOT)
        val safeClipCount = clipCount.coerceAtLeast(1)

        // Categoria 1: Free Fire / Games
        val isFreeFire = normalized.contains("ff") ||
            normalized.contains("free fire") ||
            normalized.contains("capa") ||
            normalized.contains("highlight") ||
            normalized.contains("headshot") ||
            normalized.contains("x1") ||
            normalized.contains("game")

        // Categoria 2: Anime / AMV
        val isGojo = normalized.contains("gojo") || normalized.contains("jujutsu")
        val isNaruto = normalized.contains("naruto") || normalized.contains("sasuke")
        val isAnime = isGojo || isNaruto ||
            normalized.contains("anime") ||
            normalized.contains("amv") ||
            normalized.contains("luffy") ||
            normalized.contains("goku")

        // Categoria 3: Geral / Vlog / Transição Simples
        val isVlog = normalized.contains("vlog") ||
            normalized.contains("viagem") ||
            normalized.contains("rotina") ||
            normalized.contains("dia a dia")
        val isSimple = normalized.contains("simples") ||
            normalized.contains("suave") ||
            normalized.contains("limpa") ||
            isVlog

        // Modificadores específicos
        val has4k = normalized.contains("4k") || normalized.contains("nitidez") || normalized.contains("ultra")
        val hasSlow = normalized.contains("lento") || normalized.contains("slow") || normalized.contains("twixtor")
        val hasBeat = normalized.contains("batida") || normalized.contains("beat") || normalized.contains("forte") || normalized.contains("seco") || normalized.contains("impacto")
        val hasFlash = normalized.contains("flash") || normalized.contains("branco") || isFreeFire
        val hasShake = normalized.contains("shake") || normalized.contains("tremor") || normalized.contains("camera") || isFreeFire
        val hasContrast = normalized.contains("contraste") || normalized.contains("escuro") || normalized.contains("dark") || isAnime

        val resolvedTransition = when {
            isFreeFire && selectedTransition == TransitionStyle.SIMPLE -> TransitionStyle.ZOOM_IMPACT
            hasFlash && selectedTransition == TransitionStyle.SIMPLE -> TransitionStyle.WHITE_FLASH
            (hasBeat || isAnime) && selectedTransition == TransitionStyle.SIMPLE -> TransitionStyle.HARD_CUT_BEAT_SYNC
            hasSlow && selectedTransition == TransitionStyle.SIMPLE -> TransitionStyle.SLOW_MOTION
            else -> selectedTransition
        }

        val resolvedResolution = if (has4k || isAnime) TargetResolution.UHD_4K else resolution

        val cutIntervalMs = when {
            isFreeFire -> 700L
            isSimple && !hasBeat && !isAnime -> 2400L
            hasBeat || resolvedTransition == TransitionStyle.HARD_CUT_BEAT_SYNC -> 850L
            hasSlow || resolvedTransition == TransitionStyle.SLOW_MOTION -> 1900L
            isAnime -> 1050L
            mode == StudioMode.SINGLE_VIDEO_REMIX -> 1500L
            else -> 1400L
        }

        val baseSpeed = when {
            hasSlow || resolvedTransition == TransitionStyle.SLOW_MOTION -> 0.65f
            isFreeFire -> 1.18f
            isAnime && !hasBeat -> 0.92f
            hasBeat -> 1.12f
            else -> 1.0f
        }

        val speedRamp = hasSlow || hasBeat || isFreeFire || isAnime || mode == StudioMode.SINGLE_VIDEO_REMIX

        val zoomIntensity = when {
            isFreeFire -> 1.28f
            isGojo || resolvedTransition == TransitionStyle.ZOOM_IMPACT -> 1.24f
            hasShake -> 1.18f
            isSimple -> 1.05f
            else -> 1.12f
        }

        val flashEnabled = hasFlash || resolvedTransition == TransitionStyle.WHITE_FLASH || isGojo || isFreeFire
        val contrastBoost = when {
            hasContrast || isAnime -> 0.35f
            isFreeFire -> 0.30f
            has4k -> 0.25f
            else -> 0.14f
        }
        val saturationBoost = when {
            isFreeFire -> 24f
            isNaruto -> 18f
            isAnime -> 14f
            isVlog -> 8f
            else -> 6f
        }
        val sharpness4k = if (resolvedResolution == TargetResolution.UHD_4K || has4k || isAnime) 1.0f else 0.60f
        val cameraShake = if (isFreeFire || hasShake || hasBeat) 0.80f else 0.12f

        val totalMs = duration.seconds * 1000L
        val segments = buildList {
            var cursorMs = 0L
            var index = 0
            while (cursorMs < totalMs) {
                val segLen = minOf(cutIntervalMs, totalMs - cursorMs)
                val clipIdx = index % safeClipCount
                val segSpeed = if (speedRamp && index % 3 == 1) (baseSpeed * 0.78f).coerceIn(0.45f, 1.5f) else baseSpeed
                val segZoom = if (index % 2 == 0) zoomIntensity else 1.02f
                val clipOffsetStart = ((index / safeClipCount) * 1800L)
                add(
                    ClipCutSegment(
                        clipIndex = clipIdx,
                        startMs = clipOffsetStart,
                        endMs = clipOffsetStart + segLen,
                        speedFactor = segSpeed,
                        zoomScale = segZoom,
                        applyFlash = flashEnabled && index > 0
                    )
                )
                cursorMs += segLen
                index++
            }
        }

        val themeTag = when {
            isFreeFire -> "FREE_FIRE_HIGHLIGHT"
            isGojo -> "ANIME_GOJO_IMPACT"
            isNaruto -> "ANIME_NARUTO_CINEMATIC"
            isAnime -> "ANIME_AMV_4K"
            isVlog -> "VLOG_CLEAN_EDIT"
            mode == StudioMode.SINGLE_VIDEO_REMIX -> "REMIX_4K_MASTER"
            isSimple -> "CLEAN_SIMPLE_EDIT"
            else -> "PRO_STUDIO_EDIT"
        }

        val summary = buildString {
            append("Roteiro local [$themeTag]: cortes de ${cutIntervalMs}ms")
            append(", zoom ${String.format(Locale.US, "%.2fx", zoomIntensity)}")
            if (flashEnabled) append(", flash branco ativo")
            if (speedRamp) append(", speed ramp dinâmico")
            if (cameraShake > 0.3f) append(", camera shake")
            append(", masterização ${resolvedResolution.shortLabel}.")
        }

        return EditScript(
            engineSource = "Motor Inteligente Local",
            themeTag = themeTag,
            targetDurationSec = duration.seconds,
            resolution = resolvedResolution,
            transitionStyle = resolvedTransition,
            cutIntervalMs = cutIntervalMs,
            baseSpeedFactor = baseSpeed,
            speedRampEnabled = speedRamp,
            zoomIntensity = zoomIntensity,
            flashEnabled = flashEnabled,
            contrastBoost = contrastBoost,
            saturationBoost = saturationBoost,
            sharpness4k = sharpness4k,
            cameraShakeIntensity = cameraShake,
            segments = segments,
            summaryNote = summary
        )
    }
}
