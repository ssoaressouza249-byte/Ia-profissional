package com.raylan.iaprofissional.engine

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.raylan.iaprofissional.model.EditScript
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object VideoRenderEngine {

    @OptIn(UnstableApi::class)
    suspend fun renderAndSaveToGallery(
        context: Context,
        inputUris: List<Uri>,
        script: EditScript,
        onProgress: (Int, String) -> Unit
    ): Result<Pair<Uri, String>> = withContext(Dispatchers.Main) {
        runCatching {
            require(inputUris.isNotEmpty()) { "Selecione pelo menos um vídeo da galeria." }

            onProgress(5, "Configurando Media3 Transformer...")
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFileName = "IA_Profissional_${script.resolution.shortLabel.replace(" ", "_")}_$timestamp.mp4"
            val tempOutputFile = File(context.cacheDir, outputFileName)
            if (tempOutputFile.exists()) tempOutputFile.delete()

            val editedItems = buildEditedSequence(inputUris, script)
            val sequence = EditedMediaItemSequence.Builder(editedItems).build()
            val composition = Composition.Builder(listOf(sequence)).build()

            val encoderFactory = DefaultEncoderFactory.Builder(context)
                .setRequestedVideoEncoderSettings(
                    VideoEncoderSettings.Builder()
                        .setBitrate(script.resolution.bitrateBps)
                        .build()
                )
                .build()

            val exportCompletion = CompletableDeferred<Unit>()
            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoderFactory)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (!exportCompletion.isCompleted) {
                            exportCompletion.complete(Unit)
                        }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        if (!exportCompletion.isCompleted) {
                            exportCompletion.completeExceptionally(exportException)
                        }
                    }
                })
                .build()

            transformer.start(composition, tempOutputFile.absolutePath)

            val progressHolder = ProgressHolder()
            val pollJob = launch {
                while (isActive && !exportCompletion.isCompleted) {
                    val state = transformer.getProgress(progressHolder)
                    val pct = when (state) {
                        Transformer.PROGRESS_STATE_AVAILABLE -> progressHolder.progress.coerceIn(5, 92)
                        Transformer.PROGRESS_STATE_WAITING_FOR_AVAILABILITY -> 10
                        else -> 15
                    }
                    onProgress(pct, "Renderizando ${script.resolution.shortLabel} ($pct%)...")
                    delay(200)
                }
            }

            try {
                exportCompletion.await()
            } finally {
                pollJob.cancel()
            }

            onProgress(95, "Salvando em Movies/IAProfissional...")
            val galleryUri = saveMp4ToMediaStore(
                context = context,
                sourceFile = tempOutputFile,
                displayName = outputFileName
            ).getOrThrow()

            runCatching { tempOutputFile.delete() }
            onProgress(100, "Renderização concluída!")
            galleryUri to outputFileName
        }
    }

    @OptIn(UnstableApi::class)
    private fun buildEditedSequence(
        inputUris: List<Uri>,
        script: EditScript
    ): List<EditedMediaItem> {
        val segments = script.segments.ifEmpty {
            listOf(
                com.raylan.iaprofissional.model.ClipCutSegment(
                    clipIndex = 0,
                    startMs = 0L,
                    endMs = script.targetDurationSec * 1000L,
                    speedFactor = script.baseSpeedFactor,
                    zoomScale = script.zoomIntensity,
                    applyFlash = script.flashEnabled
                )
            )
        }

        return segments.mapIndexed { index, segment ->
            val sourceUri = inputUris[segment.clipIndex % inputUris.size]
            val startMs = segment.startMs.coerceAtLeast(0L)
            val endMs = (segment.endMs).coerceAtLeast(startMs + 450L)

            val mediaItem = MediaItem.Builder()
                .setUri(sourceUri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build()
                )
                .build()

            val videoEffects = buildList<Effect> {
                add(Presentation.createForHeight(script.resolution.heightPx))

                // Zoom de impacto / enquadramento dinâmico
                add(
                    ScaleAndRotateTransformation.Builder()
                        .setScale(segment.zoomScale, segment.zoomScale)
                        .setRotationDegrees(
                            if (script.cameraShakeIntensity > 0.4f && index % 2 == 1) 1.2f else 0f
                        )
                        .build()
                )

                // Color grading de anime e nitidez/contraste 4K
                add(Contrast(script.contrastBoost))
                add(
                    HslAdjustment.Builder()
                        .adjustSaturation(script.saturationBoost)
                        .adjustLightness(if (segment.applyFlash && index % 2 == 0) 6f else 0f)
                        .build()
                )

                // Pulso de brilho/flash branco na entrada de batida
                if (segment.applyFlash) {
                    val flashScale = 1.0f + (0.14f * script.sharpness4k)
                    add(
                        RgbAdjustment.Builder()
                            .setRedScale(flashScale)
                            .setGreenScale(flashScale)
                            .setBlueScale(flashScale)
                            .build()
                    )
                }

                // Slow motion / Speed Ramp via SpeedChangeEffect
                if (segment.speedFactor != 1.0f) {
                    val speedProvider = object : SpeedProvider {
                        override fun getSpeed(timeUs: Long): Float = segment.speedFactor
                        override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
                    }
                    add(SpeedChangeEffect(speedProvider))
                }
            }

            EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(emptyList(), videoEffects))
                .build()
        }
    }

    fun saveMp4ToMediaStore(
        context: Context,
        sourceFile: File,
        displayName: String
    ): Result<Uri> = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_MOVIES}/IAProfissional"
                )
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }

            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, contentValues)
                ?: error("Falha ao criar registro no MediaStore.")

            resolver.openOutputStream(itemUri)?.use { output ->
                sourceFile.inputStream().use { input ->
                    input.copyTo(output)
                }
            } ?: error("Não foi possível abrir fluxo de escrita no MediaStore.")

            contentValues.clear()
            contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(itemUri, contentValues, null, null)
            itemUri
        } else {
            @Suppress("DEPRECATION")
            val moviesDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "IAProfissional"
            )
            if (!moviesDir.exists()) moviesDir.mkdirs()
            val destFile = File(moviesDir, displayName)
            sourceFile.copyTo(destFile, overwrite = true)

            val contentValues = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.DATA, destFile.absolutePath)
            }
            context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
                ?: Uri.fromFile(destFile)
        }
    }
}
